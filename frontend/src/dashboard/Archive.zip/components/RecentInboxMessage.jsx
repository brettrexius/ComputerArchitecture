import React, {Component} from 'react';

class RecentInboxMessage extends Component {
  state = {
  }
  render(){
    return(
      <div className="recent-inbox-message">
        
      </div>
    )
  }
}

export default RecentInboxMessage;