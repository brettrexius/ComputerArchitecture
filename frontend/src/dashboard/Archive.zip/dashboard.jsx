import React, {Component} from 'react';
import './dashboard.css'
import OutgoingMessage from './components/OutgoingMessage';

class DashBoard extends Component {
  state = {
    messageContent: "",
    // outMsgs: [{msg: "Hello World", avt: "0", date: new Date()},{msg: "Ayy", avt: "O", date: new Date()}],
    outMsgs: [],
    inMsgs: []
  }
  sendMessage(){
    let newMsg = {msg: this.messageContent.value, avt: "0", date: new Date()};
    let newState = this.state.outMsgs.concat(newMsg);
    this.setState({outMsgs:newState});
  }
  render(){
    return(
      <div className="dashboard">
        <div className="container">
          <div className="row">
            <div className="col-sm-5">
              {/* <div className="inbox-box">
                <div className="header-inbox-box"> 
                  <div className="row">
                    <div class="header-recent col"><h4>Recent</h4></div>
                    <div class="header-search col">
                      <div class="stylish-input-group">
                        <input type="text" class="header-search-bar" placeholder="Search"/>
                        <span class="header-search-button">
                          <button type="button"> <i class="fa fa-search" aria-hidden="true"></i> </button>
                        </span> 
                      </div>
                    </div>
                  </div>
                </div>
              </div> */}

            </div>{/* <End>: inbox-box*/}

            <div className="col-sm-7">
              <div className="row">
                <div className="message-history">
                {this.state.outMsgs.map((item, key) =>
                  <OutgoingMessage content={item}></OutgoingMessage>
                )}
                  {/* <OutgoingMessage content={{msg: "Hello world", avt: "O", date: new Date}}></OutgoingMessage> */}
                </div>
              </div>
              <div className="row">
                <div className="message-input-area">
                  <input ref={msg => this.messageContent = msg} type="text" className="message-input" placeholder="Type a message"/>
                  <button onClick={() => this.sendMessage()} className="send-message-button" type="button"><i className="fa fa-paper-plane-o" aria-hidden="true"></i></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default DashBoard;